package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Doctor;
import com.example.demo.error.DoctorNotFoundException;

public interface DoctorService {

	Doctor saveDoctor(Doctor doctor);

	List<Doctor> fetchDoctorList();

	void deleteDoctorById(Integer did) throws DoctorNotFoundException;

	void updateDoctor(Integer did, Doctor doctor) throws DoctorNotFoundException;

	Doctor fetchDoctorById(Integer did) throws DoctorNotFoundException;

	Doctor fetchDoctorByName(String name) throws DoctorNotFoundException;

	Doctor fetchDoctorByEmailid(String emailid) throws DoctorNotFoundException;





}
